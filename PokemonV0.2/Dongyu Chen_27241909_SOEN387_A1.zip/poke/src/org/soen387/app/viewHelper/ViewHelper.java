package org.soen387.app.viewHelper;

public interface ViewHelper {

	public String toJson();
}
